"""
Battle Scene - Grid-based combat with MMBN-style mechanics.
- 1-3 enemies per battle
- Custom screen chip selection (5 chips drawn, 15 sec window)
- Buster when no chips loaded
- Sword attacks are melee (hit adjacent tiles)
- Progress bar for next custom screen
"""

import pygame
import math
import random
from scenes.base_scene import BaseScene
from combat.chips import Chip, CHIP_DATABASE, roll_chip_drop


class Projectile:
    """A moving projectile on the battle grid."""
    def __init__(self, x, y, dx, dy, damage, color, from_enemy=True, speed=4.0):
        self.x, self.y = float(x), float(y)
        self.dx, self.dy = dx, dy
        self.damage = damage
        self.color = color
        self.from_enemy = from_enemy
        self.alive = True
        self.speed = speed


class SlashEffect:
    """Visual effect for sword attacks."""
    def __init__(self, positions, color, duration=0.3):
        self.positions = positions  # List of (grid_x, grid_y)
        self.color = color
        self.timer = duration
        self.max_time = duration


class Enemy:
    """An enemy virus in battle."""
    def __init__(self, name, hp, attack, defense, x, y, is_boss=False):
        self.name = name
        self.hp = hp
        self.max_hp = hp
        self.attack = attack
        self.defense = defense
        self.x = x
        self.y = y
        self.is_boss = is_boss
        self.attack_timer = random.uniform(0.5, 1.5)  # Stagger attacks
        self.move_timer = random.uniform(0.3, 0.8)
        self.alive = True


class BattleScene(BaseScene):
    """Grid-based battle with custom screen chip selection."""
    
    target_fps = 24
    
    def __init__(self, manager, enemy: dict = None, area: dict = None, **kwargs):
        super().__init__(manager)
        self.area = area or {}
        
        # Grid: 3 rows x 6 cols
        self.grid_cols = 6
        self.grid_rows = 3
        self.cell_width = 40
        self.cell_height = 28
        self.grid_x = (self.width - self.grid_cols * self.cell_width) // 2
        self.grid_y = 70
        
        # Spawn 1-3 enemies
        self.enemies = self._spawn_enemies(enemy)
        
        # Navi state
        self.navi_x, self.navi_y = 1, 1
        self.navi_move_timer = 0.0
        self.navi_buster_timer = 0.0
        self.buster_cooldown = 0.8  # Auto-fire buster every 0.8 sec
        
        # Projectiles and effects
        self.projectiles = []
        self.slash_effects = []
        
        # Custom screen / chip system
        self.custom_gauge = 0.0  # Fills up to trigger custom screen
        self.custom_gauge_max = 15.0  # 15 seconds between custom screens
        self.in_custom_screen = False
        self.drawn_chips = []
        self.selected_chips = []  # Chips selected this custom screen
        self.chip_cursor = 0
        self.chip_queue = []  # Chips queued to use
        
        # Battle state
        self.phase = "intro"  # intro, battle, custom, win, lose
        self.phase_timer = 1.0
        
        # Animation
        self.anim_timer = 0.0
        self.hit_flash = 0.0
        self.shake = 0.0
        
        # Damage popups
        self.damage_popups = []
        
        # Rewards (scales with enemy count)
        self.rewards = {"zenny": 0, "chips": []}
        self.battle_result = None
    
    def _spawn_enemies(self, enemy_data):
        """Spawn 1-3 enemies based on area difficulty."""
        enemies = []
        enemy_data = enemy_data or {}
        
        # Determine enemy count (1-3, weighted towards fewer)
        roll = random.random()
        if roll < 0.5:
            count = 1
        elif roll < 0.85:
            count = 2
        else:
            count = 3
        
        # Enemy templates
        virus_types = [
            {"name": "Mettaur", "hp": 40, "attack": 10, "defense": 2},
            {"name": "Spikey", "hp": 50, "attack": 12, "defense": 1},
            {"name": "Bunny", "hp": 35, "attack": 15, "defense": 0},
            {"name": "Fishy", "hp": 45, "attack": 14, "defense": 2},
            {"name": "Canodumb", "hp": 60, "attack": 8, "defense": 4},
        ]
        
        # If boss fight, spawn single tough enemy
        if enemy_data.get("is_boss"):
            boss = Enemy(
                enemy_data.get("name", "BossVirus"),
                enemy_data.get("hp", 120),
                enemy_data.get("attack", 20),
                enemy_data.get("defense", 5),
                4, 1, is_boss=True
            )
            return [boss]
        
        # Spawn regular enemies at different positions
        positions = [(4, 0), (5, 1), (4, 2), (5, 0), (5, 2)]
        random.shuffle(positions)
        
        for i in range(count):
            template = random.choice(virus_types)
            pos = positions[i]
            e = Enemy(
                template["name"],
                template["hp"],
                template["attack"],
                template["defense"],
                pos[0], pos[1]
            )
            enemies.append(e)
        
        return enemies
    
    def update(self, dt):
        self.anim_timer += dt
        self.hit_flash = max(0, self.hit_flash - dt * 5)
        self.shake = max(0, self.shake - dt * 8)
        
        # Update damage popups
        for p in self.damage_popups[:]:
            p[3] -= dt
            if p[3] <= 0:
                self.damage_popups.remove(p)
        
        # Update slash effects
        for s in self.slash_effects[:]:
            s.timer -= dt
            if s.timer <= 0:
                self.slash_effects.remove(s)
        
        # Phase logic
        if self.phase == "intro":
            self.phase_timer -= dt
            if self.phase_timer <= 0:
                self.phase = "battle"
                # Start with full gauge so player can open custom immediately
                self.custom_gauge = self.custom_gauge_max
        
        elif self.phase == "battle":
            self._update_battle(dt)
        
        elif self.phase == "custom":
            pass  # Waiting for player input
        
        elif self.phase in ["win", "lose"]:
            self.phase_timer -= dt
    
    def _update_battle(self, dt):
        """Update active battle."""
        # Update projectiles
        self._update_projectiles(dt)
        
        # Update Navi AI
        self._update_navi(dt)
        
        # Update enemies
        self._update_enemies(dt)
        
        # Fill custom gauge (but don't auto-open)
        self.custom_gauge += dt
        self.custom_gauge = min(self.custom_gauge, self.custom_gauge_max)  # Cap at max
        
        # Check win/lose
        if all(not e.alive for e in self.enemies):
            self._win()
        elif self.game_state["navi"]["hp"] <= 0:
            self._lose()
    
    def _update_projectiles(self, dt):
        """Move projectiles and check collisions."""
        for proj in self.projectiles[:]:
            proj.x += proj.dx * proj.speed * dt
            proj.y += proj.dy * proj.speed * dt
            
            # Out of bounds
            if proj.x < -1 or proj.x > self.grid_cols or proj.y < -1 or proj.y > self.grid_rows:
                proj.alive = False
                continue
            
            # Enemy projectile hits Navi
            if proj.from_enemy and proj.alive:
                if abs(proj.x - self.navi_x) < 0.5 and abs(proj.y - self.navi_y) < 0.5:
                    self._navi_hit(proj.damage)
                    proj.alive = False
            
            # Navi projectile hits enemies
            if not proj.from_enemy and proj.alive:
                for enemy in self.enemies:
                    if enemy.alive:
                        if abs(proj.x - enemy.x) < 0.6 and abs(proj.y - enemy.y) < 0.6:
                            self._enemy_hit(enemy, proj.damage)
                            proj.alive = False
                            break
        
        self.projectiles = [p for p in self.projectiles if p.alive]
    
    def _update_navi(self, dt):
        """Navi AI: dodge and auto-fire buster only. Player uses chips manually."""
        # Movement
        self.navi_move_timer += dt
        if self.navi_move_timer >= 0.5:
            self.navi_move_timer = 0
            self._navi_ai_move()
        
        # Auto-fire buster only (AI doesn't use chips)
        self.navi_buster_timer += dt
        if self.navi_buster_timer >= self.buster_cooldown:
            self.navi_buster_timer = 0
            self._fire_buster()
    
    def _navi_ai_move(self):
        """Navi dodges projectiles and moves tactically."""
        # Check for incoming danger
        danger_row = None
        for proj in self.projectiles:
            if proj.from_enemy and proj.dx < 0 and 0 < proj.x < 3.5:
                if abs(proj.y - self.navi_y) < 0.6:
                    danger_row = int(round(proj.y))
                    break
        
        if danger_row is not None:
            # Dodge to safe row
            safe = [r for r in range(3) if r != danger_row]
            if safe:
                safe.sort(key=lambda r: abs(r - self.navi_y))
                self.navi_y = safe[0]
                return
        
        # Random movement
        if random.random() < 0.3:
            if random.random() < 0.7:
                # Vertical
                self.navi_y = random.randint(0, 2)
            else:
                # Horizontal
                self.navi_x = max(0, min(2, self.navi_x + random.choice([-1, 1])))
    
    def _fire_buster(self):
        """Fire Navi's basic buster shot. Base damage is 1 + buster_attack from NaviCust."""
        navi = self.game_state["navi"]
        # Base buster damage is 1, plus NaviCust Attack level
        buster_attack = navi.get("buster_attack", 1)
        
        proj = Projectile(
            self.navi_x + 0.5, self.navi_y,
            1, 0,  # Moving right
            buster_attack,  # Low damage, upgradeable via NaviCust
            (255, 255, 100),  # Yellow
            from_enemy=False,
            speed=8.0
        )
        self.projectiles.append(proj)
    
    def _use_chip(self, chip):
        """Use a battle chip."""
        if chip.chip_type in ["sword", "widesword", "longsword"]:
            self._use_sword(chip)
        elif chip.chip_type == "attack":
            self._fire_chip_projectile(chip)
        elif chip.chip_type == "heal":
            navi = self.game_state["navi"]
            navi["hp"] = min(navi["max_hp"], navi["hp"] + chip.power)
            sx, sy = self._grid_to_screen(self.navi_x, self.navi_y)
            self.damage_popups.append([sx, sy - 20, f"+{chip.power}", 1.0, self.colors["hp_green"]])
    
    def _use_sword(self, chip):
        """Execute a sword attack hitting tiles in pattern."""
        hit_positions = []
        
        for dx, dy in chip.range_pattern:
            target_x = self.navi_x + dx
            target_y = self.navi_y + dy
            
            if 0 <= target_x < self.grid_cols and 0 <= target_y < self.grid_rows:
                hit_positions.append((target_x, target_y))
                
                # Check if enemy is in this tile
                for enemy in self.enemies:
                    if enemy.alive and enemy.x == target_x and int(enemy.y) == target_y:
                        self._enemy_hit(enemy, chip.power)
        
        # Visual slash effect
        color = self.colors["accent_cyan"]
        if "Fire" in chip.name:
            color = (255, 100, 50)
        elif "Aqua" in chip.name:
            color = (50, 150, 255)
        
        self.slash_effects.append(SlashEffect(hit_positions, color, 0.25))
    
    def _fire_chip_projectile(self, chip):
        """Fire a chip-based projectile."""
        proj = Projectile(
            self.navi_x + 0.5, self.navi_y,
            1, 0,
            chip.power,
            self.colors["accent_cyan"],
            from_enemy=False,
            speed=6.0
        )
        self.projectiles.append(proj)
    
    def _update_enemies(self, dt):
        """Update enemy AI - movement and attacks."""
        for enemy in self.enemies:
            if not enemy.alive:
                continue
            
            # Movement
            enemy.move_timer -= dt
            if enemy.move_timer <= 0:
                enemy.move_timer = random.uniform(0.6, 1.2)
                self._enemy_move(enemy)
            
            # Attack
            enemy.attack_timer -= dt
            if enemy.attack_timer <= 0:
                enemy.attack_timer = random.uniform(1.0, 2.0)
                self._enemy_attack(enemy)
    
    def _enemy_move(self, enemy):
        """Enemy movement AI."""
        if random.random() < 0.5:
            return  # Sometimes stay still
        
        if random.random() < 0.6:
            # Vertical - track Navi
            if enemy.y < self.navi_y and enemy.y < 2:
                enemy.y += 1
            elif enemy.y > self.navi_y and enemy.y > 0:
                enemy.y -= 1
        else:
            # Horizontal
            if enemy.x < 5 and random.random() < 0.3:
                enemy.x += 1
            elif enemy.x > 3 and random.random() < 0.4:
                enemy.x -= 1
        
        enemy.x = max(3, min(5, enemy.x))
        enemy.y = max(0, min(2, enemy.y))
    
    def _enemy_attack(self, enemy):
        """Enemy fires at Navi."""
        color = (255, 100, 50) if enemy.is_boss else (255, 180, 50)
        proj = Projectile(
            enemy.x - 0.5, enemy.y,
            -1, 0,
            enemy.attack,
            color,
            from_enemy=True,
            speed=3.5
        )
        self.projectiles.append(proj)
    
    def _navi_hit(self, damage):
        """Navi takes damage."""
        navi = self.game_state["navi"]
        actual = max(1, damage - navi["defense"])
        navi["hp"] = max(0, navi["hp"] - actual)
        self.hit_flash = 1.0
        self.shake = 1.0
        sx, sy = self._grid_to_screen(self.navi_x, self.navi_y)
        self.damage_popups.append([sx, sy - 20, f"-{actual}", 1.0, self.colors["hp_red"]])
    
    def _enemy_hit(self, enemy, damage):
        """Enemy takes damage."""
        actual = max(1, damage - enemy.defense)
        enemy.hp -= actual
        if enemy.hp <= 0:
            enemy.alive = False
        self.shake = 0.4
        sx, sy = self._grid_to_screen(enemy.x, enemy.y)
        self.damage_popups.append([sx, sy - 20, f"-{actual}", 1.0, self.colors["accent_cyan"]])
    
    def _open_custom_screen(self):
        """Open chip selection screen."""
        self.phase = "custom"
        self.custom_gauge = 0
        
        # Draw 5 chips from folder
        folder = self.game_state["chip_folder"]
        self.drawn_chips = folder.draw_chips(5)
        self.selected_chips = []
        self.chip_cursor = 0
        
        # If folder empty, skip custom screen
        if not self.drawn_chips:
            self.phase = "battle"
    
    def _close_custom_screen(self):
        """Close custom screen and queue selected chips."""
        self.chip_queue = self.selected_chips.copy()
        self.selected_chips = []
        self.phase = "battle"
    
    def _win(self):
        """Victory!"""
        self.phase = "win"
        self.phase_timer = 2.5
        
        # Calculate rewards based on enemy count
        base_zenny = sum(20 + e.max_hp for e in self.enemies)
        self.rewards = {"zenny": base_zenny, "chips": []}
        self.game_state["zenny"] += base_zenny
        
        # Roll for chip drops from each enemy (3-5% chance each)
        for enemy in self.enemies:
            dropped = roll_chip_drop(enemy.name)
            if dropped:
                self.rewards["chips"].append(dropped)
                self.game_state["chip_folder"].add_chip(dropped)
        
        self.battle_result = "win"
    
    def _lose(self):
        """Defeat..."""
        self.phase = "lose"
        self.phase_timer = 2.5
        self.battle_result = "lose"
        # HP restoration handled by hub/main game (1 hour wait)
    
    def handle_event(self, event):
        if event.type != pygame.USEREVENT:
            return
        action = event.dict.get("action")
        
        if self.phase == "battle":
            # Press Z to open custom screen when gauge is full
            if action == "confirm" and self.custom_gauge >= self.custom_gauge_max:
                self._open_custom_screen()
            # Press X to use next queued chip
            elif action == "cancel" and self.chip_queue:
                self._use_chip(self.chip_queue.pop(0))
        
        elif self.phase == "custom":
            if action == "left":
                self.chip_cursor = max(0, self.chip_cursor - 1)
            elif action == "right":
                self.chip_cursor = min(len(self.drawn_chips) - 1, self.chip_cursor + 1)
            elif action == "confirm":
                # Select/deselect chip
                if self.chip_cursor < len(self.drawn_chips):
                    chip = self.drawn_chips[self.chip_cursor]
                    if chip in self.selected_chips:
                        self.selected_chips.remove(chip)
                    elif len(self.selected_chips) < 5:
                        self.selected_chips.append(chip)
            elif action == "cancel" or action == "start":
                # Close custom screen and use selected chips
                self._close_custom_screen()
        
        elif self.phase in ["win", "lose"] and action == "confirm":
            if self.phase == "win":
                self.manager.pop_scene()
            else:
                self.manager.change_scene("hub")
    
    def _grid_to_screen(self, gx, gy):
        """Convert grid to screen coordinates."""
        sx = self.grid_x + int(gx) * self.cell_width + self.cell_width // 2
        sy = self.grid_y + int(gy) * self.cell_height + self.cell_height // 2
        return sx, sy
    
    def draw(self, screen):
        screen.fill((15, 15, 25))
        
        shake_x = int(math.sin(self.anim_timer * 50) * self.shake * 3) if self.shake > 0 else 0
        
        # Draw grid
        self._draw_grid(screen, shake_x)
        
        # Draw slash effects
        self._draw_slashes(screen, shake_x)
        
        # Draw projectiles
        self._draw_projectiles(screen, shake_x)
        
        # Draw enemies
        for enemy in self.enemies:
            if enemy.alive:
                self._draw_enemy(screen, enemy, shake_x)
        
        # Draw Navi
        self._draw_navi(screen, shake_x)
        
        # Draw popups
        self._draw_popups(screen)
        
        # Draw UI
        self._draw_ui(screen)
        
        # Custom screen overlay
        if self.phase == "custom":
            self._draw_custom_screen(screen)
        
        # Win/Lose
        if self.phase == "win":
            self._draw_win(screen)
        elif self.phase == "lose":
            self._draw_lose(screen)
    
    def _draw_grid(self, screen, shake_x):
        """Draw MMBN-style battle grid."""
        for row in range(self.grid_rows):
            for col in range(self.grid_cols):
                x = self.grid_x + col * self.cell_width + shake_x
                y = self.grid_y + row * self.cell_height
                
                if col < 3:
                    panel_color = (40, 80, 160)
                    panel_light = (60, 110, 200)
                    panel_dark = (25, 50, 110)
                else:
                    panel_color = (160, 50, 60)
                    panel_light = (200, 70, 80)
                    panel_dark = (110, 30, 40)
                
                # Panel with 3D effect
                pygame.draw.rect(screen, panel_color, (x+1, y+1, self.cell_width-2, self.cell_height-2))
                pygame.draw.line(screen, panel_light, (x+2, y+2), (x+self.cell_width-3, y+2), 2)
                pygame.draw.line(screen, panel_dark, (x+2, y+self.cell_height-3), (x+self.cell_width-3, y+self.cell_height-3), 2)
                pygame.draw.rect(screen, (80, 80, 100), (x, y, self.cell_width, self.cell_height), 1)
    
    def _draw_slashes(self, screen, shake_x):
        """Draw sword slash effects."""
        for slash in self.slash_effects:
            alpha = int(255 * (slash.timer / slash.max_time))
            for gx, gy in slash.positions:
                sx, sy = self._grid_to_screen(gx, gy)
                sx += shake_x
                # Draw slash arc
                pygame.draw.arc(screen, slash.color, (sx-15, sy-15, 30, 30), 0.5, 2.5, 3)
                pygame.draw.arc(screen, (255,255,255), (sx-12, sy-12, 24, 24), 0.7, 2.3, 2)
    
    def _draw_projectiles(self, screen, shake_x):
        """Draw projectiles."""
        for proj in self.projectiles:
            sx = self.grid_x + proj.x * self.cell_width + shake_x
            sy = self.grid_y + proj.y * self.cell_height + self.cell_height // 2
            pygame.draw.circle(screen, proj.color, (int(sx), int(sy)), 5)
            pygame.draw.circle(screen, (255, 255, 200), (int(sx), int(sy)), 2)
    
    def _draw_enemy(self, screen, enemy, shake_x):
        """Draw an enemy."""
        sx, sy = self._grid_to_screen(enemy.x, enemy.y)
        sx += shake_x
        
        size = 16 if enemy.is_boss else 12
        color = (200, 60, 60) if enemy.is_boss else (180, 140, 60)
        bob = math.sin(self.anim_timer * 3 + enemy.x) * 2
        
        pygame.draw.circle(screen, color, (int(sx), int(sy - bob)), size)
        pygame.draw.circle(screen, (255, 255, 255), (int(sx), int(sy - bob)), size, 2)
        
        # Eyes
        pygame.draw.circle(screen, (255, 255, 255), (int(sx-4), int(sy-3-bob)), 3)
        pygame.draw.circle(screen, (255, 255, 255), (int(sx+4), int(sy-3-bob)), 3)
        pygame.draw.circle(screen, (0, 0, 0), (int(sx-4), int(sy-3-bob)), 1)
        pygame.draw.circle(screen, (0, 0, 0), (int(sx+4), int(sy-3-bob)), 1)
        
        # HP bar
        bar_w = 24
        hp_pct = enemy.hp / enemy.max_hp
        pygame.draw.rect(screen, (40, 20, 20), (sx - bar_w//2, sy - size - 10, bar_w, 4))
        pygame.draw.rect(screen, (220, 60, 60), (sx - bar_w//2, sy - size - 10, int(bar_w * hp_pct), 4))
    
    def _draw_navi(self, screen, shake_x):
        """Draw Navi."""
        sx, sy = self._grid_to_screen(self.navi_x, self.navi_y)
        sx += shake_x
        
        if self.hit_flash > 0 and int(self.hit_flash * 10) % 2 == 0:
            return
        
        bob = math.sin(self.anim_timer * 4) * 2
        pygame.draw.circle(screen, (0, 100, 220), (int(sx), int(sy - bob)), 11)
        pygame.draw.circle(screen, (0, 220, 200), (int(sx), int(sy - bob)), 11, 2)
        pygame.draw.ellipse(screen, (0, 220, 200), (sx-6, sy-3-bob, 12, 5))
    
    def _draw_popups(self, screen):
        """Draw damage numbers."""
        for popup in self.damage_popups:
            x, y, text, timer, color = popup
            y -= (1.0 - timer) * 15
            self.draw_text(screen, text, int(x), int(y), size=12, center=True, color=color)
    
    def _draw_ui(self, screen):
        """Draw battle HUD."""
        navi = self.game_state["navi"]
        
        # Navi HP
        self.draw_panel(screen, 2, 2, 75, 20, border_width=1)
        self.draw_progress_bar(screen, 5, 5, 68, 8, navi["hp"], navi["max_hp"])
        self.draw_text(screen, f"{navi['hp']}", 5, 14, size=9, color=self.colors["text_white"])
        
        # Queued chips display
        if self.chip_queue:
            self.draw_panel(screen, 2, 25, 75, 20, border_width=1)
            chip_name = self.chip_queue[0].name[:8]
            self.draw_text(screen, f"[X]{chip_name}", 5, 28, size=10, color=self.colors["accent_cyan"])
            if len(self.chip_queue) > 1:
                self.draw_text(screen, f"+{len(self.chip_queue)-1}", 65, 28, size=8, color=self.colors["text_dim"])
        
        # Custom gauge bar (bottom of screen)
        gauge_pct = self.custom_gauge / self.custom_gauge_max
        bar_w = self.width - 20
        pygame.draw.rect(screen, (30, 30, 50), (10, self.height - 12, bar_w, 8))
        pygame.draw.rect(screen, self.colors["accent_cyan"], (10, self.height - 12, int(bar_w * gauge_pct), 8))
        pygame.draw.rect(screen, (100, 100, 120), (10, self.height - 12, bar_w, 8), 1)
        
        # "CUSTOM" label - only show when ready
        if gauge_pct >= 1.0:
            self.draw_text(screen, "[Z] CUSTOM!", self.width - 60, self.height - 11, size=10, color=self.colors["accent_cyan"])
        else:
            pct_text = f"{int(gauge_pct * 100)}%"
            self.draw_text(screen, pct_text, self.width - 30, self.height - 11, size=9, color=self.colors["text_dim"])
        
        # Enemy count
        alive = sum(1 for e in self.enemies if e.alive)
        self.draw_text(screen, f"Virus: {alive}", self.width - 50, 5, size=10, color=self.colors["text_dim"])
    
    def _draw_custom_screen(self, screen):
        """Draw chip selection overlay."""
        # Darken background
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        self.draw_text(screen, "SELECT CHIPS", self.width // 2, 15, size=14, center=True, color=self.colors["accent_cyan"])
        self.draw_text(screen, f"Selected: {len(self.selected_chips)}/5", self.width // 2, 32, size=10, center=True, color=self.colors["text_dim"])
        
        # Draw chips
        card_w, card_h = 50, 55
        total = len(self.drawn_chips) * (card_w + 4) - 4
        start_x = (self.width - total) // 2
        y = 50
        
        for i, chip in enumerate(self.drawn_chips):
            x = start_x + i * (card_w + 4)
            is_cursor = i == self.chip_cursor
            is_selected = chip in self.selected_chips
            
            # Card background
            if is_selected:
                bg = self.colors["hp_green"]
            elif is_cursor:
                bg = self.colors["accent_cyan"]
            else:
                bg = self.colors["bg_panel"]
            
            self.draw_panel(screen, x, y, card_w, card_h, color=bg, border_width=2 if is_cursor else 1)
            
            tc = self.colors["bg_dark"] if (is_cursor or is_selected) else self.colors["text_white"]
            self.draw_text(screen, chip.name[:6], x + card_w // 2, y + 8, size=9, center=True, color=tc)
            self.draw_text(screen, str(chip.power), x + card_w // 2, y + 25, size=14, center=True, color=tc)
            self.draw_text(screen, chip.chip_type[:4], x + card_w // 2, y + 42, size=8, center=True, color=tc)
        
        self.draw_text(screen, "[Z] Select  [X] Done", self.width // 2, self.height - 20, size=10, center=True, color=self.colors["text_dim"])
    
    def _draw_win(self, screen):
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        screen.blit(overlay, (0, 0))
        
        self.draw_text(screen, "VICTORY!", self.width // 2, 40, size=22, center=True, color=self.colors["accent_cyan"])
        self.draw_text(screen, f"+{self.rewards['zenny']}z", self.width // 2, 70, size=16, center=True, color=self.colors["accent_yellow"])
        
        # Show dropped chips
        y = 95
        if self.rewards["chips"]:
            self.draw_text(screen, "GOT CHIP:", self.width // 2, y, size=12, center=True, color=self.colors["hp_green"])
            for chip_name in self.rewards["chips"]:
                y += 15
                self.draw_text(screen, chip_name, self.width // 2, y, size=14, center=True, color=self.colors["accent_pink"])
        
        self.draw_text(screen, "[Z] Continue", self.width // 2, self.height - 25, size=11, center=True, color=self.colors["text_dim"])
    
    def _draw_lose(self, screen):
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((40, 0, 0, 160))
        screen.blit(overlay, (0, 0))
        
        self.draw_text(screen, "DELETED...", self.width // 2, self.height // 2 - 20, size=22, center=True, color=self.colors["hp_red"])
        self.draw_text(screen, "Wait 1 hour to recover", self.width // 2, self.height // 2 + 10, size=11, center=True, color=self.colors["text_dim"])
        self.draw_text(screen, "[Z] Continue", self.width // 2, self.height - 25, size=11, center=True, color=self.colors["text_dim"])
