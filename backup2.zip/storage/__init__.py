"""Storage package."""
from storage.save_manager import SaveManager
