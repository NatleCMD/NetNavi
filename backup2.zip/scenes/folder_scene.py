"""
Folder Scene - Chip folder management with add/remove.
Optimized for 128x128 display - shows 3 chips at a time.
"""

import pygame
from scenes.base_scene import BaseScene
from combat.chips import CHIP_DATABASE


class FolderScene(BaseScene):
    """Manage battle chip folder - add and remove chips."""
    
    target_fps = 30
    
    def __init__(self, manager):
        super().__init__(manager)
        self.selected_index = 0
        self.scroll_offset = 0
        self.max_visible = 3  # Reduced from 5 for 128x128
        self.mode = "folder"  # folder or library
        self.library_index = 0
    
    def handle_event(self, event):
        if event.type != pygame.USEREVENT:
            return
        action = event.dict.get("action")
        folder = self.game_state["chip_folder"]
        
        if self.mode == "folder":
            if action == "up":
                self.selected_index = max(0, self.selected_index - 1)
                self._update_scroll()
            elif action == "down":
                self.selected_index = min(len(folder.chips) - 1, self.selected_index + 1)
                self._update_scroll()
            elif action == "confirm":
                # Remove chip from folder
                if folder.chips:
                    folder.chips.pop(self.selected_index)
                    self.selected_index = min(self.selected_index, len(folder.chips) - 1)
            elif action == "start":
                # Switch to library to add chips
                self.mode = "library"
                self.library_index = 0
            elif action == "cancel":
                self.manager.pop_scene()
        
        elif self.mode == "library":
            library = list(CHIP_DATABASE.keys())
            if action == "up":
                self.library_index = max(0, self.library_index - 1)
            elif action == "down":
                self.library_index = min(len(library) - 1, self.library_index + 1)
            elif action == "confirm":
                # Add chip to folder
                if len(folder.chips) < folder.max_size:
                    chip_name = library[self.library_index]
                    folder.add_chip(chip_name)
            elif action == "cancel":
                self.mode = "folder"
    
    def _update_scroll(self):
        if self.selected_index < self.scroll_offset:
            self.scroll_offset = self.selected_index
        elif self.selected_index >= self.scroll_offset + self.max_visible:
            self.scroll_offset = self.selected_index - self.max_visible + 1
    
    def draw(self, screen):
        screen.fill(self.colors["bg_dark"])
        
        self.draw_panel(screen, 2, 2, self.width - 4, 20)
        self.draw_text(screen, "FOLDER", self.width // 2, 6,
                      size=14, center=True, color=self.colors["accent_cyan"])
        
        folder = self.game_state["chip_folder"]
        
        if self.mode == "folder":
            self._draw_folder(screen, folder)
        else:
            self._draw_library(screen, folder)
    
    def _draw_folder(self, screen, folder):
        y = 28
        item_height = 30  # Reduced from 32
        
        if not folder.chips:
            self.draw_text(screen, "Empty!", self.width // 2, 60,
                          size=10, center=True, color=self.colors["text_dim"])
        else:
            for i, chip in enumerate(folder.chips[self.scroll_offset:self.scroll_offset + self.max_visible]):
                idx = self.scroll_offset + i
                sel = idx == self.selected_index
                bg = self.colors["accent_cyan"] if sel else self.colors["bg_panel"]
                self.draw_panel(screen, 4, y, self.width - 8, item_height - 2, color=bg, border_width=1)
                tc = self.colors["bg_dark"] if sel else self.colors["text_white"]
                
                # Chip name (larger)
                self.draw_text(screen, chip.name, 8, y + 3, size=10, color=tc)
                # Power
                self.draw_text(screen, str(chip.power), self.width - 40, y + 3, size=10, color=tc)
                # Type (smaller, below)
                self.draw_text(screen, chip.chip_type[:6], 8, y + 16, size=7, color=tc)
                y += item_height
        
        # Scroll indicators
        if self.scroll_offset > 0:
            self.draw_text(screen, "▲", self.width // 2, 26, size=10, center=True, color=self.colors["accent_cyan"])
        if self.scroll_offset + self.max_visible < len(folder.chips):
            self.draw_text(screen, "▼", self.width // 2, self.height - 30, size=10, center=True, color=self.colors["accent_cyan"])
        
        # Counter
        self.draw_text(screen, f"{len(folder.chips)}/{folder.max_size}",
                      self.width // 2, self.height - 20, size=9, center=True,
                      color=self.colors["text_dim"])
        
        # Controls
        self.draw_text(screen, "[Z]Del [START]Add [X]Back",
                      self.width // 2, self.height - 8, size=7, center=True,
                      color=self.colors["text_dim"])
    
    def _draw_library(self, screen, folder):
        # Overlay
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        self.draw_text(screen, "ADD CHIP", self.width // 2, 8,
                      size=12, center=True, color=self.colors["accent_cyan"])
        
        library = list(CHIP_DATABASE.keys())
        max_vis = 4  # Reduced from 6
        scroll = max(0, self.library_index - max_vis + 1)
        
        y = 24
        item_height = 24  # Reduced
        
        for i, chip_name in enumerate(library[scroll:scroll + max_vis]):
            idx = scroll + i
            sel = idx == self.library_index
            chip = CHIP_DATABASE[chip_name]
            
            bg = self.colors["accent_cyan"] if sel else self.colors["bg_panel"]
            self.draw_panel(screen, 8, y, self.width - 16, item_height - 2, color=bg, border_width=1)
            
            tc = self.colors["bg_dark"] if sel else self.colors["text_white"]
            self.draw_text(screen, chip_name[:10], 12, y + 3, size=9, color=tc)
            self.draw_text(screen, str(chip.power), self.width - 28, y + 3, size=9, color=tc)
            # Type below
            self.draw_text(screen, chip.chip_type[:6], 12, y + 14, size=6, color=tc)
            y += item_height
        
        self.draw_text(screen, f"{len(folder.chips)}/{folder.max_size}",
                      self.width // 2, self.height - 20, size=8, center=True,
                      color=self.colors["text_dim"])
        self.draw_text(screen, "[Z]Add [X]Back",
                      self.width // 2, self.height - 8, size=7, center=True,
                      color=self.colors["text_dim"])
